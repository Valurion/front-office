<?php
// This is a dummy file that must be writable by the user that exectute the PHP script.
// E.g. the web server user www-data, www, httpd or similar
// Run 'php readMetadata.php' to initialize this file
$metadataIDProviders = Array();
?>