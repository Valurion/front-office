<?php // Copyright (c) 2013, SWITCH - Serving Swiss Universities ?>
	
	<!-- Body: End -->
		</div>
	</div>

</div>
</body>
</html>